create database capston_project;
use capston_project;
show tables;
select * from End_project;

/*********************************************************************************************************************************/
/*2. Substitution Patterns
What is the average number of substitutions made per match across teams, and how does this vary by league or season?
Are substitutions more likely to occur during specific time intervals (e.g., first half vs. second half)?
How do substitution strategies (e.g., attacking or defensive substitutions) differ based on match situations (e.g., leading, tied, trailing)?
Are specific players more frequently subbed in or out, and what are their positional or performance characteristics?
*/

/*********************************************************************************************************************************/
-- Task-1 = What is the average number of substitutions made per match across teams, and how does this vary by league or season?

select season,competition_type,type_x,team_captain,count(*) as 'Total Substitution',avg(game_event_id) as 'Average Substitution' from End_project
group by season,competition_type,team_captain,type_x
order by 4 desc
limit 20;

/* Interpretation:
In the 2015 domestic_league the average substitution is 0,and its total substitution is 828 it is in peak.
Using avg and count function i has displayed these all top=20 records of average number of substitutions made per match across teams*/

/*********************************************************************************************************************************/
-- Task-2 = Are substitutions more likely to occur during specific time intervals (e.g., first half vs. second half)?

select minutes_played,player_name_x,type_x,
case
when minute <=45 then 'First Half'
when minute >=45 then 'Second Half'
else 'Final Part'
end as 'Substitution time intervals players played'
from End_project
order by minute desc;

/* Interpretation:
"Fabian Johnson" played in 'Second Half' with 70.70580333154219 minutes played ,he is the person in top 20,
The Second player is "Emmanuel Sabbi" also played in second half with a minutes played of 84.
The Third player is "Fabian Johnson" even played in second half with 70.70580333154219 minutes played.*/

/*********************************************************************************************************************************/
-- Task-3 = How do substitution strategies (e.g., attacking or defensive substitutions) differ based on match situations (e.g., leading, tied, trailing)?

select minute,minutes_played,player_name_x,type_x,home_club_goals, away_club_goals,
case
when home_club_goals>away_club_goals then 'Leading'  -- winning
when away_club_goals<home_club_goals then 'Trailing'   -- losing
else 'Tied'  -- Draw
end as 'Substitution Strategies',
case
when description in ('Injury') then 'Attacking'
when description in ('Tactical') then 'Defensive Substitution'
else 'Others'
end as 'Playing strategy1',
case
when position_x in ('Attacking Midfield') then 'Attacking'
when position_x in ('Defensive Midfield') then 'Defensive Substitution'
else 'Others'
end as 'Playing strategy2',
case
when position_y in ('Attack') then 'Attacking'
when position_y in ('Defender') then 'Defensive Substitution'
else 'Others'
end as 'Playing strategy3'
from End_project
order by 5,6 desc;

/* Interpretation:
When home goals is greater than away goals it means 'Home win" / 'Leading'
when away goals is less than home goals it means 'Away win"/ Trailing
if else 'Tied' / 'Draw'.

When description='Injury' it means 'Attacking'
when description ='Tactical it means 'Defensive substitution'
if else it refers 'others'

when position_y in ('Attack') then 'Attacking'
when position_y in ('Defender') then 'Defensive Substitution'
else 'other'

So in conclusion most of this home goals and away goals with 1 and 3 is Tied with a playing stratety2 is 'Attacking'
and some of players are in defensive substitution and some in not in any category.*/

/*********************************************************************************************************************************/
-- Task-4 = Are specific players more frequently subbed in or out, and what are their positional or performance characteristics?

-- players are subbed in:
select player_name_x,type_x,position_x,sub_position,position_y,sum(goals),sum(assists),avg(minutes_played),count(game_event_id)
from End_project
where type_x in ('Substitutions')
group by player_name_x,type_x,position_x,sub_position,position_y ;

/* Interpretation:
Using select,where and group by clause i have identified that most of the players are in substitutions (subbed in) and thier
position/performance is in "Midfield,Defender,Goalkeeper,Attack" with the count attendance(game event id) =44.*/

/*********************************************************************************************************************************/
-- players are not subbed in:
select player_name_x,type_x,position_x,sub_position,position_y,sum(goals),sum(assists),avg(minutes_played),count(game_event_id)
from End_project
where type_x not in ('Substitutions') 
group by player_name_x,type_x,position_x,sub_position,position_y ;

-- Player name list that they are subbed in.
/*A.J. Soares
Alejandro Bedoya
Alfredo Morales
Andrija Novakovich
Aron Johannsson
Babajide Ogunbiyi
Bill Hamid
Bobby Wood
Brad Friedel
Brad Guzan
Brek Shea
Brendan Hines-Ike
Caleb Patterson-Sewell
Caleb Stanko
Cameron Carter-Vickers
Charlie Davies
Chris Durkin
Chris Richards
Christian Cappis
Christian Pulisic
Clarence Goodson
Clint Dempsey
Conor O'Brien
Danny Williams
David Yelldell
DeAndre Yedlin
Desevio Payne
Dillon Powers
Don Cowan
Emerson Hyndman
Emmanuel Sabbi
Eric Lichaj
Erik Palmer-Brown
Ethan Horvath
Eugene Starikov
Fabian Johnson
Gedion Zelalem
Geoff Cameron
George Fochive
Giovanni Reyna
Ian Harkes
Indiana Vassilev
Jermaine Jones
Jerome Kiesewetter
Joe Gyau
John Anthony Brooks
Jonathan Amon
Jonathan Klinsmann
Jonathan Spector
Jordan
Joseph Efford
Josh Sargent
Jozy Altidore
Juan Agudelo
Juan Torres
Julian Green
Keaton Parks
Kenny Saief
Khiry Shelton
Kyle Scott
Luca de la Torre
Lynden Gooch
Matt Miazga
Matt Polster
Maurice Edu
Michael Bradley
Michael Lansing
Michael Parkhurst
Mike Grella
Oguchi Onyewu
Owen Otasowie
Perry Kitchen
Reggie Cannon
Russell Canouse
Sacha Kljestan
Sebastian Soto
Sergino Dest
Seyi Adekoya
Shane O'Neill
Shaq Moore
Steve Clark
Steven Cherundolo
Terrence Boyd
Tim Howard
Tim Ream
Timothy Chandler
Timothy Weah
Tyler Adams
Weston McKennie
Yosef Samuel
Zack Steffen*/

/*********************************************************************************************************************************/
-- Player name list that they are not subbed in.
/*Jermaine Jones
Jermaine Jones
Steven Cherundolo
Brad Friedel
Tim Howard
Tim Howard
Oguchi Onyewu
Oguchi Onyewu
Fabian Johnson
Clint Dempsey
Clint Dempsey
Michael Bradley
Michael Bradley
Fabian Johnson
Fabian Johnson
Geoff Cameron
Geoff Cameron
Danny Williams
Danny Williams
Fabian Johnson
Jozy Altidore
Jozy Altidore
Clarence Goodson
Clarence Goodson
Brad Guzan
Sacha Kljestan
Sacha Kljestan
Michael Parkhurst
Michael Parkhurst
Charlie Davies
Timothy Chandler
Timothy Chandler
Fabian Johnson
Maurice Edu
Alfredo Morales
Fabian Johnson
Eric Lichaj
Bobby Wood
Fabian Johnson
Fabian Johnson
Fabian Johnson
Terrence Boyd
Fabian Johnson
Eugene Starikov
Fabian Johnson
Alejandro Bedoya
Alejandro Bedoya
Aron Johannsson
Aron Johannsson
John Anthony Brooks
John Anthony Brooks
Fabian Johnson
Juan Agudelo
Juan Agudelo
Babajide Ogunbiyi
Babajide Ogunbiyi
Julian Green
Conor O'Brien
Conor O'Brien
Sebastian Lletget
A.J. Soares
Caleb Stanko
Fabian Johnson
Kenny Saief
Fabian Johnson
Fabian Johnson
Fabian Johnson
Emerson Hyndman
Fabian Johnson
Matt Miazga
DeAndre Yedlin
Desevio Payne
Erik Palmer-Brown
Fabian Johnson
Christian Pulisic
Weston McKennie
Tyler Adams
Andrija Novakovich
Jordan
Sergino Dest
Fabian Johnson
Chris Durkin
Timothy Weah
Fabian Johnson
Fabian Johnson
Emmanuel Sabbi
Fabian Johnson
Josh Sargent
Seyi Adekoya
Giovanni Reyna
Fabian Johnson
Joseph Efford
Jonathan Amon
Christian Cappis*/
/*********************************************************************************************************************************/




